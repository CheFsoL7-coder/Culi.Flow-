import streamlit as st
import sqlite3
import pandas as pd
from datetime import datetime

# Database connection
DB_PATH = "fv_dashboard.db"

def get_connection():
    return sqlite3.connect(DB_PATH, check_same_thread=False)

conn = get_connection()
cur = conn.cursor()

# Sidebar: User Selection
st.sidebar.title("👤 User Login")
user = st.sidebar.text_input("Enter your name", value="Chef")

# Tabs
tab = st.sidebar.radio("Navigate", ["QA Checklist", "Inventory", "Feedback", "Copilot Brief"])

st.title("👨‍🍳 Friendship Village Culinary Dashboard")

# QA Checklist
if tab == "QA Checklist":
    st.header("✅ Daily QA Compliance Checklist")
    date = st.date_input("Checklist Date", datetime.now())
    tasks = ["Cooler Temps Checked", "FIFO Rotation Complete", "Test Meals Observed", "Line-Up Attended"]

    for task in tasks:
        status = st.selectbox(f"{task}:", ["Pending", "Complete"], key=task)
        if st.button(f"Log '{task}'"):
            cur.execute("INSERT INTO checklist_logs (user, date, task, status) VALUES (?, ?, ?, ?)",
                        (user, str(date), task, status))
            conn.commit()
            st.success(f"Logged: {task} as {status}")

# Inventory
elif tab == "Inventory":
    st.header("📦 Inventory Tracker")
    st.subheader("Current Stock Levels")
    inv_df = pd.read_sql_query("SELECT * FROM inventory", conn)
    st.dataframe(inv_df)

    st.subheader("Add / Update Item")
    item = st.text_input("Item name")
    qty = st.number_input("Quantity", min_value=0, step=1)
    reorder = st.number_input("Reorder Point", min_value=0, step=1)
    if st.button("Save Inventory Item"):
        cur.execute("INSERT INTO inventory (item, quantity, reorder_point) VALUES (?, ?, ?)", (item, qty, reorder))
        conn.commit()
        st.success(f"{item} saved to inventory.")

# Feedback
elif tab == "Feedback":
    st.header("🗣 Resident Feedback Logger")
    name = st.text_input("Resident Name")
    concept = st.selectbox("Dining Concept", ["Main Dining", "Oak Terrace", "Loons Nest"])
    meal = st.selectbox("Meal", ["Breakfast", "Lunch", "Dinner"])
    mood = st.radio("Resident Mood", ["😀 Happy", "😐 Neutral", "🙁 Unhappy"])
    comment = st.text_area("Feedback")

    if st.button("Submit Feedback"):
        ts = datetime.now().isoformat()
        cur.execute("INSERT INTO feedback (resident_name, concept, meal, mood, comment, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
                    (name, concept, meal, mood, comment, ts))
        conn.commit()
        st.success("Feedback logged successfully!")

# Copilot Brief
elif tab == "Copilot Brief":
    st.header("📝 Daily Copilot Brief Summary")
    today = datetime.now().date()
    logs = pd.read_sql_query("SELECT * FROM checklist_logs WHERE date = ?", conn, params=(str(today),))
    feedbacks = pd.read_sql_query("SELECT * FROM feedback WHERE DATE(timestamp) = ?", conn, params=(str(today),))

    st.subheader("Summary Metrics")
    st.write(f"🧾 Total checklist logs today: {len(logs)}")
    st.write(f"💬 Feedback entries: {len(feedbacks)}")

    brief = st.text_area("Write Copilot Summary", height=200)
    if st.button("Save Brief"):
        cur.execute("INSERT INTO copilot_brief (date, summary) VALUES (?, ?)", (str(today), brief))
        conn.commit()
        st.success("Summary saved!")