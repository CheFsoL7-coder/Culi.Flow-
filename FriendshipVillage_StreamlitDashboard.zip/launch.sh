#!/bin/bash

echo "📦 Setting up Friendship Village Dashboard..."

# Unzip if needed
if [ ! -f fv_dashboard.py ]; then
    unzip FriendshipVillage_StreamlitDashboard.zip
    cd FriendshipVillage_StreamlitDashboard || exit
fi

# Install dependencies
pip install -r requirements.txt

# Run the dashboard
streamlit run fv_dashboard.py