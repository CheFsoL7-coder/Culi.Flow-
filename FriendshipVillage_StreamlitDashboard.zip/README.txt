# 📦 Friendship Village Streamlit Dashboard

## 🖥 Requirements:
- Python 3.8+
- pip

## 🚀 To Run:

```bash
unzip FriendshipVillage_StreamlitDashboard.zip
cd FriendshipVillage_StreamlitDashboard
pip install -r requirements.txt
streamlit run fv_dashboard.py
```

The dashboard will auto-launch in your browser (http://localhost:8501)